
import { combineReducers } from 'redux'
import { productReducer, productSelectedReducer } from '../productReducer'


const rootReducer= combineReducers({
    allProducts: productReducer,
    product:productSelectedReducer
})

export default rootReducer