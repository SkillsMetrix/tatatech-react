import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import axios from "axios";
import { selectedProduct } from "../redux/actions/productActions";
function ProductDetails(props) {
  const data = useSelector((state) => state.product);
  const { title, category, image, price, description } = data;
  const dispatch = useDispatch();
  const URL = "https://fakestoreapi.com/products";
  const { pid } = useParams();

  const loadProduct = async () => {
    const response = await axios.get(`${URL}/${pid}`);
    dispatch(selectedProduct(response.data));
  };
  useEffect(() => {
    loadProduct();
  }, []);
  console.log(data);

  return (
    <div className="ui grid container">
      <div className="ui placeholder segment">
        <div className="ui two columns stackable center aligned grid">
          <div className="ui vertical divider">AND</div>
          <div className="middle aligned row">
            <div className="column lp">
              <img className="ui fluid image" src={image} />
            </div>
            <div className="column rp">
              <h1>{title}</h1>
              <h2>
                <a className="ui teal tag label">${price}</a>
              </h2>

              <h3 className="ui brown block header">{category}</h3>
              <p>{description}</p>
              <div className="ui vertical animated button" tabIndex="0">
                <div className="hidden content">
                  <i className="shop icon"></i>
                </div>
                <div className="visible content">Add To Cart</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetails;
